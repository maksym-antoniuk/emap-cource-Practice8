CREATE PROCEDURE mysqllab.error_district()
  BEGIN
  SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Data cannot be deleted.' ;
END;
