CREATE FUNCTION mysqllab.isExistTable(sch VARCHAR(40), tbl VARCHAR(40))
  RETURNS TINYINT(1)
  begin
	declare coun int default 0;
	SELECT count(*)
	FROM information_schema.TABLES
	WHERE (TABLE_SCHEMA = sch) AND (TABLE_NAME = tbl) into coun;
    if(coun = 0) then return false;
    else return true;
	end if;
end;
