CREATE PROCEDURE mysqllab.addUnit(IN nameser VARCHAR(45))
  begin
	insert into unit(`name`) values(nameser);
end;
