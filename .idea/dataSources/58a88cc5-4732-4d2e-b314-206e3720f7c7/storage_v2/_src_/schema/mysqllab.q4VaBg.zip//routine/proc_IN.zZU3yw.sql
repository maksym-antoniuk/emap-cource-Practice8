CREATE PROCEDURE mysqllab.proc_IN(IN var_IN INT)
  BEGIN  
    SELECT var_IN - 7 AS result;  
END;
