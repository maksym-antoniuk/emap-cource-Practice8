CREATE FUNCTION mysqllab.isAuthorize(login VARCHAR(45), pass VARCHAR(45))
  RETURNS INT
  begin
	declare var int default 0;
    select isLogin(login) into var;
    if(var = 1) then 
		begin
			declare pas int default 0;
            select count(*) from `user` where `name` = login AND `password` = pass into pas;
            if(pas = 1) then return 1;
            else return 0;
            end if;
        end;
    else return -1;
    end if;
end;
