CREATE PROCEDURE mysqllab.addService(IN nameser VARCHAR(45), IN notat TEXT, IN pric FLOAT, IN idun INT)
  begin
	insert into service(`name`, `notation`, `price`, `unit_idunit`) values(nameser, notat, pric, idun);
end;
