CREATE PROCEDURE mysqllab.addDepartment(IN nameser VARCHAR(45), IN addr VARCHAR(45), IN dat DATE)
  begin
	insert into department(`name`,`address`,`date_foundation`,`value`) values(nameser,addr,dat,1.6);
end;
