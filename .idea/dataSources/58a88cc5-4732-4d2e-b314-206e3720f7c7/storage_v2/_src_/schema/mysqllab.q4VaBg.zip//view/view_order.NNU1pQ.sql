CREATE VIEW mysqllab.view_order AS
  SELECT
    `mysqllab`.`order`.`idorder`                 AS `idorder`,
    `mysqllab`.`order`.`notation`                AS `notation`,
    `mysqllab`.`order`.`hashcode`                AS `hashcode`,
    `mysqllab`.`order`.`duration`                AS `duration`,
    `mysqllab`.`order`.`date_start`              AS `date_start`,
    `mysqllab`.`order`.`date_final`              AS `date_final`,
    `mysqllab`.`order`.`department_iddepartment` AS `department_iddepartment`,
    `mysqllab`.`order`.`status_idstatus`         AS `status_idstatus`,
    `mysqllab`.`order`.`user_iduser`             AS `user_iduser`
  FROM `mysqllab`.`order`
  WHERE (`mysqllab`.`order`.`idorder` <= 100);
