CREATE TRIGGER mysqllab.my_district_discount
BEFORE DELETE ON mysqllab.discount
FOR EACH ROW
  begin 
	if((select count(*) from `user` where old.`iddiscount` = `discount_iddiscount`) > 0)
    then SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Data cannot be deleted.' ;
    end if;
end;
