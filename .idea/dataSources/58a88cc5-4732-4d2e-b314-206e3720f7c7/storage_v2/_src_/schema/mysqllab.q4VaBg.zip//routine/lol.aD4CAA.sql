CREATE PROCEDURE mysqllab.lol()
  BEGIN
drop table if exists `mainn`;
INSERT INTO `mysqllab`.`unit` (`name`) VALUES ('tiy');
select `idunit`, `name` from `mysqllab`.`unit` where `name` = 'tiy';
SET SQL_SAFE_UPDATES = 0;
update `mysqllab`.`unit` set `name` = 'tie' where `name` = 'tiy';

delete from `mysqllab`.`unit` where `name` = 'tie';

END;
