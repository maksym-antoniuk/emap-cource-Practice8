CREATE VIEW mysqllab.view_service AS
  SELECT
    `mysqllab`.`service`.`idservice`       AS `idservice`,
    `mysqllab`.`service`.`name`            AS `name`,
    `mysqllab`.`service`.`notation`        AS `notation`,
    `mysqllab`.`service`.`price`           AS `price`,
    `mysqllab`.`service`.`date_foundation` AS `date_foundation`,
    `mysqllab`.`service`.`servicecol`      AS `servicecol`,
    `mysqllab`.`service`.`unit_idunit`     AS `unit_idunit`
  FROM `mysqllab`.`service`
  WHERE (`mysqllab`.`service`.`idservice` <= 100);
