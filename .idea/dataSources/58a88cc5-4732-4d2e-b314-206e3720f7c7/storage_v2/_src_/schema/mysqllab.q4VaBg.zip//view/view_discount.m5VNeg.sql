CREATE VIEW mysqllab.view_discount AS
  SELECT
    `mysqllab`.`discount`.`iddiscount`      AS `iddiscount`,
    `mysqllab`.`discount`.`name`            AS `name`,
    `mysqllab`.`discount`.`value`           AS `value`,
    `mysqllab`.`discount`.`date_foundation` AS `date_foundation`,
    `mysqllab`.`discount`.`notation`        AS `notation`
  FROM `mysqllab`.`discount`
  WHERE (`mysqllab`.`discount`.`iddiscount` <= 100);
