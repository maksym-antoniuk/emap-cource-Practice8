CREATE VIEW mysqllab.view_dep AS
  SELECT
    `mysqllab`.`department`.`iddepartment`    AS `iddepartment`,
    `mysqllab`.`department`.`name`            AS `name`,
    `mysqllab`.`department`.`address`         AS `address`,
    `mysqllab`.`department`.`date_foundation` AS `date_foundation`,
    `mysqllab`.`department`.`value`           AS `value`
  FROM `mysqllab`.`department`
  WHERE (`mysqllab`.`department`.`iddepartment` <= 100);
