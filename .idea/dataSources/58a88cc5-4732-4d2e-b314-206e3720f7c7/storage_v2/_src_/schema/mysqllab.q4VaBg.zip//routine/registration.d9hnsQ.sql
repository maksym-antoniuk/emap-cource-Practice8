CREATE FUNCTION mysqllab.registration(login VARCHAR(45), pass VARCHAR(45), addres TEXT, birth DATE)
  RETURNS INT
  begin
	declare var int default 0;
    select isLogin(login) into var;
    if(var = 0) then 
		begin
			insert into `user`(`name`, `password`, address, birthday, role_idrole, discount_iddiscount) 
            values (login, pass, addres, birth, '1', '1');
            return 1;
        end;
    else return 0;
    end if;
end;
