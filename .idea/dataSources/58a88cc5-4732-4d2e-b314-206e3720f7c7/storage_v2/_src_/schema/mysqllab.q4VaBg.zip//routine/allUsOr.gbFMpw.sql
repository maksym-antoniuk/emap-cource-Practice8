CREATE PROCEDURE mysqllab.allUsOr(IN id INT)
  begin
	select * from `order` where user_iduser = id;
end;
