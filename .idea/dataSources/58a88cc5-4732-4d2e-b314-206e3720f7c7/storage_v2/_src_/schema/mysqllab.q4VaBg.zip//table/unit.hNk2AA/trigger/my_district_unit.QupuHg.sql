CREATE TRIGGER mysqllab.my_district_unit
BEFORE DELETE ON mysqllab.unit
FOR EACH ROW
  begin 
	if((select count(*) from `service` where old.`idunit` = `unit_idunit`) > 0)
    then SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Data cannot be deleted.' ;
    end if;
end;
