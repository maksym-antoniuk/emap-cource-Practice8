CREATE FUNCTION mysqllab.statusOrder(stat VARCHAR(256), id INT)
  RETURNS TINYINT(1)
  begin
	case stat when 'подтвержден' then update `order` set status_idstatus = 2 where idorder = id;
			when 'отклонен' then update `order` set status_idstatus = 3 where idorder = id;
			when 'выполнен' then update `order` set status_idstatus = 4 where idorder = id;
	end case;
    return true;
end;
