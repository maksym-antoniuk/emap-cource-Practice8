CREATE TRIGGER mysqllab.lol
BEFORE INSERT ON mysqllab.unit
FOR EACH ROW
  BEGIN
INSERT INTO `mysqllab`.`role` (`name`) VALUES (concat('role', new.`unit`.`idunit`)) ;

SET SQL_SAFE_UPDATES = 0;
update `unit` set `name` = 'tie' where `name` = (select version());
delete from `mysqllab`.`unit` where `name` = 'tie';
SET SQL_SAFE_UPDATES = 1;
CREATE TEMPORARY TABLE months_between_dates (month_stuff VARCHAR(7));
DROP TEMPORARY TABLE IF EXISTS months_between_dates;
END;
