CREATE TRIGGER mysqllab.my_district_user
BEFORE DELETE ON mysqllab.user
FOR EACH ROW
  begin 
	if((select count(*) from `order` where old.`iduser` = `user_iduser`) > 0)
    then SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Data cannot be deleted.' ;
    end if;
end;
