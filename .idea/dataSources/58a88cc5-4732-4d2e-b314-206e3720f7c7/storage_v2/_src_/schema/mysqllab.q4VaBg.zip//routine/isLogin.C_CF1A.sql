CREATE FUNCTION mysqllab.isLogin(login VARCHAR(45))
  RETURNS TINYINT(1)
  begin
	declare var int default 0;
	select count(*) from user where `user`.`name` = login into var;
    if(var = 1) then return true;
    else return false;
    end if;
end;
