CREATE TRIGGER mysqllab.my_district_srvice
BEFORE DELETE ON mysqllab.service
FOR EACH ROW
  begin 
	if((select count(*) from `order_has_service` where old.`idservice` = `service_idservice`) > 0)
    then SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Data cannot be deleted.' ;
    end if;
end;
