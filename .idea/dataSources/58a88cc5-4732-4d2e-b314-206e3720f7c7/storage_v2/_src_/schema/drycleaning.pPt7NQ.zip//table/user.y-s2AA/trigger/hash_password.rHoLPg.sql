CREATE TRIGGER drycleaning.hash_password
BEFORE INSERT ON drycleaning.user
FOR EACH ROW
  SET NEW.password = md5(NEW.password);
