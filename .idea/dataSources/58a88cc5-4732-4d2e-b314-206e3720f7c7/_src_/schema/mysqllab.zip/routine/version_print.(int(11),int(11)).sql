CREATE PROCEDURE mysqllab.version_print(IN var INT, IN var2 INT)
  BEGIN

	declare v int default 0;
	if(var2 > var) then
    WHILE (var2 > var) DO
    set v = (v + 1);
    set var = var + 1;
    end while;
    end if;
    
    select v;
END;
