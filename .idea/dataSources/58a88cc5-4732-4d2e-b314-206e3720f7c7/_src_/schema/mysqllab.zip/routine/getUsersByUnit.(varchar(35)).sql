CREATE PROCEDURE mysqllab.getUsersByUnit(IN nameUn VARCHAR(35))
  begin
select u.`name`, u.address, o.idorder, un.`name` from `user` u
inner join `order` o on u.iduser = o.user_iduser
inner join `order_has_service` on order_idorder=o.idorder
inner join service on service_idservice = idservice
inner join unit un on unit_idunit = idunit
where un.`name` = nameUn;
end;
