CREATE PROCEDURE mysqllab.getUsOrPrice(IN nma VARCHAR(35))
  begin
	select `user`.`name`, `order`.idorder, sum(service.price * `count`) from `user`

inner join `order` on iduser = user_iduser
inner join order_has_service on order_idorder = idorder
inner join service on service_idservice = idservice
where `user`.`name` = nma
group by order_idorder;
end;
