CREATE PROCEDURE mysqllab.getUserNotAdmin()
  begin
select * from user where role_idrole IN( (select idrole from role use index(name_UNIQUE) 
where role.`name` = 'user' or role.`name` = 'men' or role.`name` = 'women' or role.`name` = 'teacher'));
end;
