CREATE PROCEDURE mysqllab.sortBySt(IN stat VARCHAR(45))
  begin

	case stat when 'подтвержден' then select * from `order` where status_idstatus = 2;
			when 'отклонен' then select * from `order` where status_idstatus = 3;
			when 'выполнен' then select * from `order` where status_idstatus = 4;
	end case;
end;
