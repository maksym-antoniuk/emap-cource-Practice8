CREATE FUNCTION mysqllab.addOrder(arr VARCHAR(256), arr1 VARCHAR(256), notat TEXT, datest DATE, dep INT, us INT)
  RETURNS TINYINT(1)
  begin
	declare art1 varchar(256);
	declare art2 varchar(256);
    declare id int default 1;
	declare element1 VARCHAR(30) default '';
	declare element2 VARCHAR(30) default '';
    set art1 = arr;
    set art2 = arr1;
    insert into `order`(notation, date_start, department_iddepartment, status_idstatus, user_iduser)
    values (notat, datest, dep, 1, us);
    set id = last_insert_id();
	WHILE art1 != '' DO

    SET element1 = SUBSTRING_INDEX(art1, ',', 1);      
    SET element2 = SUBSTRING_INDEX(art2, ',', 1);      
	
    insert into order_has_service(order_idorder, service_idservice, `count`) values(id, cast(element1 as unsigned), cast(element2 as unsigned));
	
    IF LOCATE(',', art1) > 0 THEN
    begin
      
      SET art1 = SUBSTRING(art1, LOCATE(',', art1) + 1);
      SET art2 = SUBSTRING(art2, LOCATE(',', art2) + 1);
    end;
    ELSE
      SET art1 = '';
    END IF;

  END WHILE;


	
	
    return true;
end;
