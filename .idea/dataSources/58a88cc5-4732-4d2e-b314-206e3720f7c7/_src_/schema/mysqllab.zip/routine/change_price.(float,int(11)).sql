CREATE PROCEDURE mysqllab.change_price(IN pr FLOAT, IN id INT)
  begin
	update service set price = pr where idservice = id;
end;
