CREATE PROCEDURE mysqllab.getOrderByDate(IN dat DATE)
  begin
	select * from `order` where date_final = dat;
end;
