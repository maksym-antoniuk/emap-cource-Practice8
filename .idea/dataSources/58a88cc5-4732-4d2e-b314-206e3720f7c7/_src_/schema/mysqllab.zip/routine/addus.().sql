CREATE PROCEDURE mysqllab.addus()
  begin
DECLARE v1 INT DEFAULT 1500;
DECLARE v2 INT DEFAULT 1;

  WHILE v1 > 0 DO
   select registration(concat('bnewloginbr',v2), 'passworddd4', concat('address my test2', v1), '1999-09-09');
   set v2 = v2 + 1;
    SET v1 = v1 - 1;
  END WHILE;
end;
