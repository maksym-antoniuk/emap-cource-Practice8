CREATE TRIGGER mysqllab.my_district_role
BEFORE DELETE ON mysqllab.role
FOR EACH ROW
  begin 
	if((select count(*) from `user` where old.`idrole` = `role_idrole`) > 0)
    then SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Data cannot be deleted.' ;
    end if;
end;
