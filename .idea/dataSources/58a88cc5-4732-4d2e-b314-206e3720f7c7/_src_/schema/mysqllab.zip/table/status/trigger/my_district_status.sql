CREATE TRIGGER mysqllab.my_district_status
BEFORE DELETE ON mysqllab.status
FOR EACH ROW
  begin 
	if((select count(*) from `order` where old.`idstatus` = `status_idstatus`) > 0)
    then SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Data cannot be deleted.' ;
    end if;
end;
