CREATE TRIGGER mysqllab.version_print
AFTER INSERT ON mysqllab.unit
FOR EACH ROW
  BEGIN
	
	declare var int default ROUND((RAND() * (10)));
	declare var2 int default ROUND((RAND() * (21-11))+11);
	
    WHILE (var2 > var) DO
    insert into `unit`(`name`) values(concat('tie', var));
    end while;
END;
