CREATE TRIGGER mysqllab.discount_BEFORE_INSERT
BEFORE INSERT ON mysqllab.discount
FOR EACH ROW
  BEGIN
	if ( isnull(new.date_foundation) ) then
		set new.date_foundation=curdate();
	end if;
END;
