CREATE TRIGGER mysqllab.service_BEFORE_INSERT
BEFORE INSERT ON mysqllab.service
FOR EACH ROW
  BEGIN
	if ( isnull(new.date_foundation) ) then
		set new.date_foundation=curdate();
	end if;
END;
