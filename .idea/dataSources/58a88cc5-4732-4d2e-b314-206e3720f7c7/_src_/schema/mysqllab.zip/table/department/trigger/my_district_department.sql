CREATE TRIGGER mysqllab.my_district_department
BEFORE DELETE ON mysqllab.department
FOR EACH ROW
  begin 
	if((select count(*) from `order` where old.`iddepartment` = `department_iddepartment`) > 0)
    then SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Data cannot be deleted.' ;
    end if;
end;
