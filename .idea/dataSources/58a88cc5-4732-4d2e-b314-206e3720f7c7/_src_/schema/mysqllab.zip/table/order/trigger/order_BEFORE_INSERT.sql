CREATE TRIGGER mysqllab.order_BEFORE_INSERT
BEFORE INSERT ON mysqllab.`order`
FOR EACH ROW
  BEGIN
    SET NEW.hashcode = md5(NEW.idorder);
    if ( isnull(new.date_start) ) then
		set new.date_start=curdate();
	end if;
END;
