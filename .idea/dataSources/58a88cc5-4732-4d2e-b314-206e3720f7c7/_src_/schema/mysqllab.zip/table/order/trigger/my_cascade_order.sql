CREATE TRIGGER mysqllab.my_cascade_order
BEFORE DELETE ON mysqllab.`order`
FOR EACH ROW
  begin
	if((select count(*) from `order_has_service` c where c.`order_idorder` = old.`idorder`) > 0)
    then delete from `order_has_service` where `order_idorder` = old.`idorder`;
    end if;
end;
