CREATE VIEW mysqllab.view_user AS
  SELECT
    `mysqllab`.`user`.`iduser`              AS `iduser`,
    `mysqllab`.`user`.`name`                AS `name`,
    `mysqllab`.`user`.`password`            AS `password`,
    `mysqllab`.`user`.`address`             AS `address`,
    `mysqllab`.`user`.`birthday`            AS `birthday`,
    `mysqllab`.`user`.`height`              AS `height`,
    `mysqllab`.`user`.`role_idrole`         AS `role_idrole`,
    `mysqllab`.`user`.`discount_iddiscount` AS `discount_iddiscount`
  FROM `mysqllab`.`user`
  WHERE (`mysqllab`.`user`.`iduser` <= 200);
